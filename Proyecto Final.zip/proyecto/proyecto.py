import dash
from dash import dcc
from dash import html
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
import seaborn as sns
import altair as alt
# import geopandas as gpd

app = dash.Dash()

##############################
# # # CARGA DE LOS DATOS # # #
##############################

# C:\Yeiber\semestre #8 parte 2\Visualización con python\proyecto

df_mhd = pd.read_excel('Bfinal.xlsx')

# Filtros
enfermedad = df_mhd.columns.values[[3,4,5,6,7,8,9]]
pais = df_mhd["Entity"].unique()
periodo = df_mhd["Year"].unique()



################################################################################################################################
# # #   Cuerpo del Dashboard
################################################################################################################################

app.layout = html.Div([
    html.H1(children="Prevalencia de enfermedades mentales en el mundo",
            style = {
                        'textAlign': 'center',
            }),
    html.H2(children="Por: Daniela A. Herrera y Jeiber J. Diaz"),

    ### Viz 0 ###
    html.H3(children="Visualizacion 1: Scatterplot", className="box0",
                        style={
                        'backgroundColor':'beige',
                        'color':'navy',
                        'height':'50px',
                        'margin-left':'10px',
                        'width':'60%',
                        'text-align':'center',
                        'display':'inline-block'
                        }),
    html.P(
            children="En el siguiente gráfico se puede observar la asociacion que existe entre diferentes enfermedades "
            "mentales como la depresión, la esquizofrenia y los transtornos de ansiedad por país de análisis."
        ),
    dcc.Dropdown(
                id='filtro_pais',
                options=[{'label': x, 'value': x}
                            for x in pais],
                value=['Colombia', 'Albania'],
                multi=True
        ),
    dcc.Dropdown(
        id="dropdown",
        options=[{'label': i, 'value': i} for i in enfermedad],
        value=['Depression (%)', 'Schizophrenia (%)'],
        multi=True
    ),
    html.Div(dcc.Graph(
                id='example-graph-0',
                style={'height': 1000, 'width': 1600})
            ),
    html.P("1. En Colombia se presentan asociaciones entre la depresion y enfermedades como la ansiedad, la esquizorenia, desordenes de alcohol, alimenticios y transtornos de bipolaridad. (tambien una leve asociacion frente a desordenes por consumo de drogas)"),
    html.P("2. Para el caso de Albania, no existen muchas relaciones entre enfermedades con la depresion. Se destaca la que presenta la esquizofrenia frente a los desordenes de bipolaridad, de ansiedad, por consumo de alcohol y alimenticios."),
    html.P("3. En Estados Unidos no se evidencian relaciones entre las diferentes enfermedades. Todos los comportamientos resultan muy variados"),
    html.P("En general, las formas en las que se asocian lasenfermedades entre ellas pueden variar totalmente de acuerdo al país en cuestión"),

    ### Viz 1 ###
    html.H3(children="Visualizacion 2: Stripplot", className="box1",
                        style={
                        'backgroundColor':'beige',
                        'color':'navy',
                        'height':'50px',
                        'margin-left':'10px',
                        'width':'60%',
                        'text-align':'center',
                        'display':'inline-block'
                        }),
    html.P(
            children="Mediante el stripplot se puede observar la distribución de las diferentes enfermedades mentales en el mundo a través del tiempo, observando así outliers, variabilidad de la variable y demás características"
        ),
    dcc.Dropdown(
                id='filtro_enfermedad',
                options=[{'label': i, 'value': i} for i in enfermedad],
                value='Depression (%)'
        ),
    dcc.Dropdown(
                id='filtro_year',
                options=[{'label': x, 'value': x}
                            for x in periodo],
                value=['1990','2000','2010','2017'],
                multi=True
        ),
    html.Div(dcc.Graph(
                id='example-graph-1',
                style={'height': 600, 'width': 1600})
        ),
    html.P(children="1. En general se observa un alto grado de variabilidad en las prevalencias de losdiferentes desordenes mentales en el mundo"),
    html.P("2. Existen casos particulares en los que la prevalencia de diferentes enfermedades resulta atípica. Resultan ser valores muy por encima de la media. Este comportamientos es principalmente notorio en la depresión, transtornos de alimentación (Caso particular su aumento exponencial), ansiedad y por consumo de drogas."),

    ### Viz 2

    html.Div([
        html.Div([
            html.H1(children="Visualizacion 3:Linechart", className="box2",
                        style={
                        'backgroundColor':'beige',
                        'color':'navy',
                        'height':'50px',
                        'margin-left':'10px',
                        'width':'60%',
                        'text-align':'center',
                        'display':'inline-block'
                        }
                ),
            html.P(children = "Mediante este  linechart se evidencia la evolución anual desde 1990 hasta el 2017 de diferentes prevalencias de enfermedades mentales en diferentes paises"),
            dcc.Dropdown(
                id='filtro_enfermedad3',
                options=[{'label': i, 'value': i} for i in enfermedad],
                value='Depression (%)'
            ),
            dcc.Graph(
                id='example-graph-2'
            ),
        ], className='six columns'),

    ### Viz 3 ###        
        html.Div([
            html.H1(children="Visualizacion 4: Area", className="box3",
                        style={
                        'backgroundColor':'beige',
                        'color':'navy',
                        'height':'50px',
                        'margin-left':'10px',
                        'width':'60%',
                        'text-align':'center',
                        'display':'inline-block'
                        }
                ),
            html.P(children = "Por esta visualización se pretende analizar las tendencias de las diferentes enfermedades mentalesa través del tiempo contrastandolas por paises."),
            dcc.Dropdown(
                id='filtro_pais2',
                options=[{'label': x, 'value': x}
                            for x in pais],
                value=['Colombia', 'Albania'],
                multi=True
            ),
            dcc.Graph(
                id='example-graph-3'
            ),
        ], className='six columns'),
    ],
    className = 'row'),
    html.P("1. Se observa una caida drástica en la prevalencia de la depresión en Colombia que se presenta desde el año 2005"),
    html.P("2. Albania en general no presenta gran nivel de prevalencias de enfermedades mentales, por otra parte Estados Unidos y Groenlandia presentan un alto grado en la prevalencia de diferentes enfermedades."),
    html.P("3. Paises como España e Italia, junto otros países europeos presentan comportamientos similares en estas prevalencias."),


    ### Viz 4 ###
        html.H2(children="Visualización 5. Mapa de prevalencias a nivel mundial", className="box4",
                        style={
                        'backgroundColor':'beige',
                        'color':'navy',
                        'height':'50px',
                        'margin-left':'10px',
                        'width':'60%',
                        'text-align':'center',
                        'display':'inline-block'
                        }),
        html.P(
            children="La carreta"
        ),
        dcc.Dropdown(
                id='filtro_enfermedad2',
                options=[{'label': i, 'value': i} for i in enfermedad],
                value='Depression (%)'
            ),
        dcc.Graph(
                id='example-graph-4',
                style={'height': 1200, 'width': 1600}
            ),
        html.P("1. La prevalencia de las diferentes enfermedadesmentales se centra principalmente en países de Africa y Europa, asi como también en Norte América."),
        html.P("2. Sur América y Centro América en general presentan bajos niveles en cuanto a la prevalencia de depresión en su población se refuere. Colombia, por su parte, es uno de los países que presenta de los niveles mas bajos de ella."),
        html.P("En general, las prevalencias de las diferentes enfermedades mentales consideradas resultan particularmente altas en paises desarrollados o que presentan alguna característica particular, sea por constantes conflictos sociales o su naturaleza particular."),

                        ],
                         style={'marginBottom': 50, 'marginTop': 25}
)



##############################
# # #  VISUALIZACIONES   # # #
##############################

# # visualizacion 0: sCATTERPLOT
@app.callback(
    dash.dependencies.Output('example-graph-0', 'figure'),
    [dash.dependencies.Input('filtro_pais', 'value'),
    dash.dependencies.Input('dropdown', 'value')]
    )

def update_graph(pa,dims):
    df_mhd_pa = df_mhd[df_mhd['Entity'].isin(pa)]

    fig = px.scatter_matrix(df_mhd_pa,
        dimensions=dims,
        color="Entity")


    return fig


# # visualizacion 1: stripplot
@app.callback(
    dash.dependencies.Output('example-graph-1', 'figure'),
    [dash.dependencies.Input('filtro_enfermedad', 'value'),
    dash.dependencies.Input('filtro_year', 'value')]
    )

def update_graph(enf, per):
    df_mhd_pa = df_mhd[df_mhd['Year'].isin(per)]
    columna = enf

    fig = px.strip(df_mhd_pa, x="Year", y=columna, color="Year")

    return fig  



# # Visualizacion 4. mapa
@app.callback(
    dash.dependencies.Output('example-graph-4', 'figure'),
    [dash.dependencies.Input('filtro_enfermedad2', 'value')]
    )

def update_graph(enf):
    columna = enf

    px.set_mapbox_access_token("pk.eyJ1IjoiampkaWFlc3AiLCJhIjoiY2wxdHAwcGd0MDl0dTNjcWZna29vMDlmciJ9.REDWJN58pxIys2biw8R0wQ")

    fig4 = px.scatter_mapbox(df_mhd,
                        lat='Latitud',
                        lon='Longitud',
                        hover_name='Entity',
                        zoom=3,
                        color=columna,
                        color_continuous_scale = "Bluered",
                        # mapbox_style = "mapbox://styles/mapbox/navigation-night-v1",
                        mapbox_style = "mapbox://styles/mapbox/outdoors-v11",
                        size=columna,
                        animation_frame="Year",
                        center = {"lat": 4.570868, "lon": -74.297333})
    fig4.update_layout(
        title_text = 'Prevalencia a nivel mundial',
        showlegend = True,
        geo = dict(
            scope = 'south america',
            landcolor = 'rgb(217, 217, 217)',
            )
        )

    return fig4



# Visualizaciones temporales
@app.callback(
    [dash.dependencies.Output('example-graph-2', 'figure'),
    dash.dependencies.Output('example-graph-3','figure')],
    [dash.dependencies.Input('filtro_enfermedad3', 'value'),
     dash.dependencies.Input('filtro_pais2', 'value')]
    )

def update_graph(enf, pa):
    df_mhd_pa = df_mhd[df_mhd['Entity'].isin(pa)]
    columna = enf

    fig2 = px.line(df_mhd_pa,  x="Year", y=columna, color = "Entity", symbol="Entity")
    fig3 = px.area(df_mhd_pa,  x="Year", y=columna, color = "Entity")

    return fig2,fig3



if __name__ == "__main__":
     app.run_server(debug=True)